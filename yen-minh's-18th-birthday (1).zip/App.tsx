import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Gift, Globe, MessageCircleHeart } from 'lucide-react';
import FloatingHearts from './components/FloatingHearts';
import CelebrationCard from './components/CelebrationCard';

const App: React.FC = () => {
  const [isOpened, setIsOpened] = useState(false);

  const handleOpen = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent actual navigation
    setIsOpened(true);
    triggerConfetti();
  };

  const triggerConfetti = () => {
    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#ff69b4', '#ffb7b2', '#ff9a9e', '#fad0c4']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#ff69b4', '#ffb7b2', '#ff9a9e', '#fad0c4']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-pink-200 flex items-center justify-center overflow-hidden relative font-sans">
      <FloatingHearts />

      {/* Main Content Area */}
      <div className="relative z-10 w-full h-full flex flex-col items-center justify-center p-4">
        
        {!isOpened ? (
          <div className="w-full max-w-sm animate-[fadeIn_0.8s_ease-out]">
            
            {/* Header Text */}
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center p-3 bg-white/50 backdrop-blur-sm rounded-full mb-2 shadow-sm">
                 <MessageCircleHeart className="text-rose-500 w-8 h-8 animate-bounce" />
              </div>
              <p className="text-gray-600 font-medium text-sm">Bạn có một tin nhắn mới</p>
            </div>

            {/* Message Bubble Container */}
            <div 
              className="bg-white rounded-2xl p-4 shadow-[0_10px_40px_-10px_rgba(255,105,180,0.3)] border border-pink-100 cursor-pointer transform transition-all duration-300 hover:scale-[1.02] hover:shadow-xl group"
              onClick={handleOpen}
            >
              {/* Message Header */}
              <div className="flex items-center gap-3 mb-3 border-b border-gray-100 pb-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-rose-400 to-pink-300 flex items-center justify-center text-white font-bold text-lg shadow-md">
                  A
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 text-sm">Người giấu mặt</h3>
                  <p className="text-xs text-gray-400">Vừa xong • Công khai 🌏</p>
                </div>
              </div>

              {/* Message Content */}
              <p className="text-gray-700 text-sm mb-3 leading-relaxed">
                Gửi Yến Minh, chúc mừng sinh nhật tuổi 18! Tớ có món quà nhỏ tặng cậu nè, nhấn vào link bên dưới nhé 🎂🎁
              </p>

              {/* Link Preview Card (The Fake Link) */}
              <div className="bg-gray-50 rounded-xl border border-gray-200 overflow-hidden group-hover:border-rose-300 transition-colors">
                {/* Preview Image Area */}
                <div className="h-32 bg-rose-100 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-200 to-rose-200 opacity-50"></div>
                  <Gift className="w-12 h-12 text-rose-500 relative z-10 animate-pulse" />
                  <div className="absolute bottom-2 right-2 bg-black/20 text-white text-[10px] px-1.5 py-0.5 rounded backdrop-blur-sm">
                    happy-birthday.vn
                  </div>
                </div>
                
                {/* Link Info */}
                <div className="p-3 bg-gray-50 group-hover:bg-rose-50/50 transition-colors">
                  <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-0.5 flex items-center gap-1">
                    <Globe className="w-3 h-3" /> WEBSITE
                  </p>
                  <h4 className="font-bold text-gray-800 text-sm truncate">
                    Thiệp chúc mừng sinh nhật Yến Minh 18 tuổi
                  </h4>
                  <p className="text-xs text-gray-500 truncate mt-0.5">
                    nhấn vào để mở thiệp...
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-8 text-center text-rose-400/80 text-xs font-medium animate-pulse">
              (Nhấn vào hộp tin nhắn ở trên để mở)
            </p>

          </div>
        ) : (
          <CelebrationCard onBack={() => setIsOpened(false)} />
        )}
      </div>
    </div>
  );
};

export default App;