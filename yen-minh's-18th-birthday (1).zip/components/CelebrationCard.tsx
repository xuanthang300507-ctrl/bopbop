import React from 'react';
import { Heart, Sparkles, Flower } from 'lucide-react';

interface CelebrationCardProps {
  onBack: () => void;
}

const CelebrationCard: React.FC<CelebrationCardProps> = ({ onBack }) => {
  return (
    <div className="relative z-10 max-w-lg w-full mx-4 animate-[fadeIn_1s_ease-out] my-8">
      <div className="bg-white/40 backdrop-blur-xl rounded-[2rem] shadow-[0_8px_32px_0_rgba(255,105,180,0.37)] border border-white/60 p-6 md:p-8 text-center overflow-hidden relative">
        
        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-pink-300 via-rose-400 to-pink-300" />
        
        {/* Header Icon */}
        <div className="flex justify-center mb-4 relative z-10">
          <div className="relative">
            <Heart className="w-16 h-16 text-rose-500 fill-rose-500 animate-[pulse_2s_infinite]" />
            <Sparkles className="absolute -top-1 -right-3 text-yellow-400 w-6 h-6 animate-spin-slow" />
          </div>
        </div>

        {/* Title */}
        <h1 className="font-title text-3xl md:text-5xl text-rose-600 mb-1 drop-shadow-sm">
          Happy Birthday
        </h1>
        <h2 className="font-title text-2xl md:text-3xl text-pink-500 mb-8 drop-shadow-sm">
          Yến Minh 18 Tuổi
        </h2>

        {/* Specific Message Section */}
        <div className="bg-white/50 rounded-xl p-8 shadow-inner border border-white/40 relative group hover:bg-white/60 transition-colors">
          <Flower className="absolute -top-3 -left-2 text-rose-400 w-8 h-8 animate-bounce" />
          <Flower className="absolute -bottom-3 -right-2 text-rose-400 w-8 h-8 animate-bounce delay-75" />
          
          <p className="font-handwriting text-2xl md:text-4xl text-gray-800 leading-relaxed">
            "Chúc mừng sinh nhật Yến Minh của tui tuổi 18 , luôn luôn vui vẻ hạnh phúc xinh xắn rực rỡ như hoa sophia"
          </p>
          <div className="mt-6 flex justify-center gap-2">
             <span className="text-2xl animate-bounce">🌹</span>
             <span className="text-2xl animate-bounce delay-100">🎂</span>
             <span className="text-2xl animate-bounce delay-200">💕💕💕💕🎂🎂🥳🎉🎉 🎉</span>
          </div>
        </div>

        <div className="mt-8 text-xs text-rose-400 font-medium tracking-widest uppercase opacity-70">
          Made with love
        </div>

      </div>
    </div>
  );
};

export default CelebrationCard;