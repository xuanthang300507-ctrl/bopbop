import React, { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import { FloatingHeart } from '../types';

const FloatingHearts: React.FC = () => {
  const [hearts, setHearts] = useState<FloatingHeart[]>([]);

  useEffect(() => {
    // Generate static random hearts on mount
    const newHearts: FloatingHeart[] = Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      animationDuration: `${Math.random() * 5 + 5}s`,
      opacity: Math.random() * 0.5 + 0.1,
      size: Math.random() * 20 + 10,
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute bottom-[-50px] animate-bounce"
          style={{
            left: heart.left,
            opacity: heart.opacity,
            width: `${heart.size}px`,
            height: `${heart.size}px`,
            animation: `floatUp ${heart.animationDuration} linear infinite`,
          }}
        >
          <Heart fill="currentColor" className="text-pink-300 w-full h-full" />
        </div>
      ))}
      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          20% { opacity: 0.6; }
          100% { transform: translateY(-110vh) rotate(360deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default FloatingHearts;