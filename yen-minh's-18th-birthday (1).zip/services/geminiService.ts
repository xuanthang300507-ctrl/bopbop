import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing in environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateBirthdayWish = async (): Promise<string> => {
  const ai = getClient();
  if (!ai) {
    throw new Error("Không thể kết nối với AI (Thiếu API Key).");
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Viết một lời chúc sinh nhật ngắn gọn (khoảng 2-3 câu), cực kỳ dễ thương, ngọt ngào và ý nghĩa dành cho cô gái tên Yến Minh nhân dịp tròn 18 tuổi. Sử dụng emoji.",
      config: {
        temperature: 0.8,
      }
    });

    return response.text || "Chúc mừng sinh nhật Yến Minh! Tuổi 18 rực rỡ nhé!";
  } catch (error) {
    console.error("Error generating wish:", error);
    throw new Error("Xin lỗi, AI đang bận ăn bánh kem rồi. Hãy thử lại sau nhé!");
  }
};