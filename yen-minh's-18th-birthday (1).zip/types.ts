export interface BirthdayWishState {
  loading: boolean;
  message: string | null;
  error: string | null;
}

export interface FloatingHeart {
  id: number;
  left: string;
  animationDuration: string;
  opacity: number;
  size: number;
}